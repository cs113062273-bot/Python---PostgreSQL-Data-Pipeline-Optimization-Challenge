"""Malformed-input differential tests."""

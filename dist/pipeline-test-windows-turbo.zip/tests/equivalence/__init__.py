"""Relational output oracle."""
